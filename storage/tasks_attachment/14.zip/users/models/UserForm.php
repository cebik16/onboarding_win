<?php
namespace backend\models;

use Yii;
use backend\models\User;
use yii\base\Model;

class UserForm extends Model
{
    public $password;
    public $confirm_password;
    
    public $user;

    public function load ( $data, $formName = null ) {
        return parent::load($data) && $this->user->load($data);
    }
    
    public function rules()
    {
        $rules = [
            [['password','confirm_password'], 'required', 'on' => 'create'],
            [['password','confirm_password'], 'string', 'min' => 8],
            ['password', 'match', 'pattern' => '/^(?=.*[0-9])(?=.*[A-Z])([a-zA-Z0-9]+)$/', 'message' => 'The {attribute} doesn\'t meet the necessary requirements.'],
            ['confirm_password', 'compare','compareAttribute'=>'password', 'skipOnEmpty' => false],
        ];
        return $rules;
    }
    
    public function attributeLabels()
    {
        return [

        ];
    }

    public function validate($attributeNames = NULL, $clearErrors = true){
        return parent::validate($attributeNames,$clearErrors) && $this->user->validate($attributeNames,$clearErrors);
    }

    public function save()
    {
        if ($this->validate()) {
            $isNewRecord = $this->user->isNewRecord;
            if($isNewRecord){
                $this->user->generateAuthKey();
                $this->user->setPassword($this->password);
            }else{
                if($this->password) {
                    $this->user->setPassword($this->password);
                }
            }
            return $this->user->save();
        }

        return null;
    }
}
