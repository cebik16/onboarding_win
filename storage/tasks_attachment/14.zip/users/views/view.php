<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?php if($model->status == $model::STATUS_PENDING): ?>
            <?= Html::a('Resend Activation Email', ['resend-activation-email', 'id' => $model->id], [
                'class' => 'btn btn-info',
                'data' => [
                    'confirm' => 'Are you sure you want to resend the Activation email?',
                    'method' => 'post',
                ],
            ]) ?>
        <?php endif; ?>
        <?php if($model->status == $model::STATUS_CONFIRMED): ?>
            <?= Html::a('Approve', ['approve', 'id' => $model->id], [
                'class' => 'btn btn-success',
                'data' => [
                    'confirm' => 'Are you sure you want to approve this user?',
                    'method' => 'post',
                ],
            ]) ?>
        <?php endif; ?>
        <?= Html::a('Delete', ['validate-delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'onclick' => 'return validateDelete(this);'
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'email:email',
            'first_name',
            'last_name',
            [
                'attribute' => 'status',
                'value' => $model::$statuses[$model->status]
            ],
            'created_at:datetime',
            'updated_at:datetime',
        ],
    ]) ?>

</div>

<?php $this->beginJs(); ?>
    <script type="text/javascript">
        function validateDelete(link){
            var request = $.ajax({
                url: link.href,
                type: "get",
                dataType: "json"
            });
            request.done(function (response, textStatus, jqXHR) {
                if(response.hasProjects){
                    var r = confirm("The user already has some data entered.\nAll his work will be lost.\nAre you sure you want to delete ?");
                }else{
                    var r = confirm("Are you sure you want to delete ?");
                }
                var action = addParamToUrl('<?= Url::to(['delete']); ?>','id',response.id);
                var postData = {"<?= Yii::$app->request->csrfParam; ?>": "<?= Yii::$app->request->csrfToken; ?>"}
                if (r == true) {
                    return post(action,postData);
                } else {
                    return false;
                }
                return false;
            });
            request.fail(function (jqXHR, textStatus, errorThrown){
                alert(textStatus + ': '+ errorThrown);
                return false;
            });
            return false;
        }
    </script>
<?php $this->endJs(static::POS_HEAD); ?>